[mXY, pXY] = renderPos('lrMData.mat', 'expData.mat');
% convPause()
% clearvars
% close all
% renderVel('lrMData.mat', 'expData.mat')

function convPause()
    prompt = 'Press Enter to render velocity graphs';
    str = input(prompt, 's');
    while 1
        if isempty(str)
            break;
        end
    end
    disp('Broken')
end

function [interpMXY, pXY] = renderPos(mfile, expfile)
    e_data = load(expfile,'dataset');
    %tExp = [0; e_data.dataset(62:end,1) - e_data.dataset(62,1)];
    t = e_data.dataset(:,1);
    delt = diff(e_data.dataset(:,1));
    evL = diff(e_data.dataset(:,2))./diff(e_data.dataset(:,1));
    evR = diff(e_data.dataset(:,3))./diff(e_data.dataset(:,1));
    v = (evL + evR)/2; 
    w = (evR - evL)/0.254;

    theta = cumsum([0; w .* delt]);
    y = cumsum([0; v .* sin(theta(2:end)) .* delt]);
    x = cumsum([0; v .* cos(theta(2:end)) .* delt]);
    
    mxyV = zeros(size(v,1),4);
    numMVectors = 10;
    for i=1:size(v,1)/numMVectors
        vvx = v(i*numMVectors) * cos(theta(i*numMVectors+1));
        vvy = v(i*numMVectors) * sin(theta(i*numMVectors+1));
        mxyV(i,:) = [x(i*numMVectors+1) y(i*numMVectors+1) vvx vvy];
    end
    
    load(mfile, 'tSpace', 'vMagDat', 'wMagDat')
    pV = vMagDat';
    pW = wMagDat';
    pTheta = cumsum([0; pW * mean(diff(tSpace))]);
    pX = cumsum([0; pV .* cos(pTheta(2:end)) * mean(diff(tSpace))]);
    pY = cumsum([0; pV .* sin(pTheta(2:end)) * mean(diff(tSpace))]);
    
    pxyV = zeros(size(pV,1),4);
    numPVectors = 50;
    for i=1:size(pV,1)/numPVectors
        vvx = pV(i*numPVectors) * cos(pTheta(i*numPVectors+1));
        vvy = pV(i*numPVectors) * sin(pTheta(i*numPVectors+1));
        pxyV(i,:) = [pX(i*numPVectors+1) pY(i*numPVectors+1) vvx vvy];
    end
    
    figure(1)
    plot(x,y,pX,pY)
    hold on
    quiver(mxyV(:,1), mxyV(:,2), mxyV(:,3), mxyV(:,4))
    quiver(pxyV(:,1), pxyV(:,2), pxyV(:,3), pxyV(:,4))
    legend('measured', 'predicted', 'measured tangential vectors', 'predicted tangential vectors')
    xlabel('X position (m)')
    ylabel('Y position (m)')
    title('Measured position vs. Predicted position of the NEATO')
    
    t = t(61:283) - t(61);
    x = x(61:283);
    y = y(61:283);
    
    interpMXY = [interp1(t,x,tSpace') interp1(t,y,tSpace')];
    pXY = [pX(2:end) pY(2:end)];
    errXY = interpMXY - pXY;
    err = zeros(size(errXY,1));
    for i=1:size(errXY)
        err(i) = norm(errXY(i,:));
    end
    figure(2)
    plot(tSpace',err)
    xlabel('Time (s)')
    ylabel('Error (m)')
    title('Distance from desired path vs. time')
end

function renderVel(mfile, expfile)
    close all
    t_data = load(mfile,'lrData','alpha','vMagDat','wMagDat');
    alpha = t_data.alpha;
    tvL = t_data.lrData(:,1);
    tvR = t_data.lrData(:,2);
    tLinV = t_data.vMagDat;
    tAngV = t_data.wMagDat;
    tTheoretical = linspace(1,pi/alpha,1000);
    e_data = load(expfile,'dataset');
    tExp = [0; e_data.dataset(62:end,1) - e_data.dataset(62,1)];
    evL = [0; diff(e_data.dataset(:,2))./diff(e_data.dataset(:,1))];
    evL = evL(61:end);
    evR = [0; diff(e_data.dataset(:,3))./diff(e_data.dataset(:,1))];
    evR = evR(61:end);
    expLinV = (evL + evR)/2;
    expAngV = (evR - evL)/0.254;
    figure(1)
    plot(tTheoretical,tvL,tTheoretical,tvR, tExp, evL, "--", tExp, evR,"--")
    legend('Predicted: vL','Predicted: vR', 'Measured: vL', 'Measured: vR')
    xlabel('Time (s)')
    ylabel('Encoder velocity (m/s)')
    title('Encoder velocities over time')
    figure(2)
    plot(tTheoretical,tLinV,tTheoretical,tAngV, ...
        tExp, expLinV, "--", tExp, expAngV, "--")
    legend('Predicted: V','Predicted: w', 'Measured: V', 'Measured: w')
    xlabel('Time (s)')
    ylabel('Encoder velocity (m/s)')
    title('Encoder velocities over time')
end