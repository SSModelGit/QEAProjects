function [countLeft, countRight] = dataCheck(filename)
    close all
    data = load(filename,'lrData','alpha');
    trackLeft = zeros([1001,1]);
    trackRight = zeros([1001,1]);
    countRight = 0;
    countLeft = 0;
    for i=1:size(data.lrData,1)
        if (data.lrData(i,1) > data.lrData(i,2))
            countRight = countRight + 1;
            trackRight(i,1) = countRight;
        else
            countLeft = countLeft + 1;
            trackLeft(i,1) = countLeft;
        end
    end
    figure(1)
    plot(trackLeft)
    hold
    plot(trackRight)
    legend('Left','Right')
end