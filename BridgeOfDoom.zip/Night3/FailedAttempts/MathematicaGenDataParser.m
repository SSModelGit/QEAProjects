function MathematicaGenDataParser(filename, maxVel)
    lrData = load(filename, 'Expression1');
    alpha = maxVel/max(max(lrData.Expression1));
    lrData = lrData.Expression1 * alpha;
    save lrData.mat lrData maxVel alpha
end