function data = standardNeato(filename, s)
    data = load(filename,'lrData','alpha');
    pub = rospublisher('/raw_vel');
    sub_bump = rossubscriber('/bump');
    msg = rosmessage(pub);
    for j=1:size(data.lrData,1)/s
        i = round(j*s);
        msg.Data = [data.lrData(i,1), data.lrData(i,2)];
        send(pub, msg)
        tic
        while 1
            if toc > pi/1000
                break
            end
        end
        bump_message = receive(sub_bump);
        if any(bump_message.Data)
            msg.Data = [0,0];
            send(pub, msg);
            break;
        end
    end
    msg.Data = [0,0];
    send(pub,msg);
end