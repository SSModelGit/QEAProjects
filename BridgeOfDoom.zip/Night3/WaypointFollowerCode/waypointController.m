clearvars
close all
waypoints = load('lrMData.mat', 'rDat');
wp = waypoints.rDat;
initQ = false;
arrivedQ = false;
des = [1 0];
pub = rospublisher('/cmd_vel', 'geometry_msgs/Twist');
msg = rosmessage(pub);
sub_encoders = rossubscriber('/encoders');
prompt = 'Press Enter to Stop Robot';
str = input(prompt, 's');
while ~arrivedQ
    if isempty(str)
        msg.Linear.X = 0;
        msg.Angular.Z = 0;
        send(pub,msg)
        break;
    else
        enc_msg = receive(sub_encoders);
        if ~initQ
            ep = enc_msg.Data';
            theta = 0;
            xy = [0 0];
            pos = zeros([100000,2]);
            ts = tic; % start timer
            tp = toc(ts); % start time
            initQ = true;
            pTick = 1;
            disp('Init.')
        else
            % calculate current position in x,y-coordinates
            en = enc_msg.Data'; % current encoder position
            tn = toc(ts); % current time
            delt = tn - tp; % time since previous update
            vLR = (en - ep) / delt; % velocity for right and left wheels
            linV = (vLR(1) + vLR(2)) / 2; % calculate the linear and angular velocities
            angV = (vLR(2) - vLR(1)) / 0.254;
            theta = theta + angV * delt; % find the change in heading
            xy(1) = xy(1) + linV * cos(theta) * delt; % find the change in x & y positions
            xy(2) = xy(2) + linV * sin(theta) * delt;
            % save to the position vector
            pos(pTick,:) = xy;
            pTick = pTick + 1;
            % Figure out updated distance & heading remaining to target
            distV = des - xy;
            distM = norm(distV);
            if distM > 0.05
                distH = atan(distV(2)/distV(1)) - theta;
                % Calculate the updated linear and angular velocities
                w = 0.8;
                if (w * distM / distH) <= 0.3
                    v = (w * distM / distH);
                else
                    v = 0.3;
                    if (v * distH / distM) <= 0.8
                        w = (v * distH / distM);
                    end
                end
                msg.Linear.X = v;
                msg.Angular.Z = w;
                send(pub,msg)
                % Prepare for next update
                tp = tn;
                ep = en;
            else
                arrivedQ = true;
                disp('Done.')
            end
        end
    end
end