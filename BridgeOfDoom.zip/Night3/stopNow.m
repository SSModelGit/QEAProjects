pub = rospublisher('/raw_vel');
msg = rosmessage(pub);
msg.Data = [0.0,0.0];
send(pub,msg);